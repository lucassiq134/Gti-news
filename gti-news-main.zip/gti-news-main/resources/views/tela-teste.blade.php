<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    @vite('resources/css/app.css')
    <title>Tela de teste</title>
</head>
<body>

<img src="hjkhkhkj.jpg" alt="">
<a href="http://"></a>



<h1 class="bg-black p-4 rounded-lg text-white">Hello Mundo teste</h1>
<button class="btn">Button</button>
<button class="btn btn-neutral">Neutral</button>
<button class="btn btn-primary">Primary</button>
<button class="btn btn-secondary">Secondary</button>
<button class="btn btn-accent">Accent</button>
<button class="btn btn-ghost">Ghost</button>
<button class="btn btn-link">Link</button>
    
</body>
</html>